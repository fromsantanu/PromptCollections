<h1>Admin</h1>
<div class="card">
  <form method="post" action="<?= url('admin/action') ?>">
    <div style="margin-bottom:12px;">
      <button class="btn" type="button" onclick="location.href='<?= url('register') ?>'">New</button>
      <button class="btn btn-outline" name="action" value="delete" type="submit">Delete</button>
      <button class="btn btn-outline" name="action" value="activate" type="submit">Activate</button>
      <button class="btn btn-outline" name="action" value="deactivate" type="submit">Deactivate</button>
      <button class="btn btn-outline" name="action" value="promote" type="submit">Promote</button>
    </div>

    <table>
      <thead>
        <tr>
          <th><input type="checkbox" onclick="toggleAll(this)" /></th>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Active</th>
          <th>Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><input type="checkbox" name="ids[]" value="<?= (int)$u['id'] ?>" /></td>
            <td><?= (int)$u['id'] ?></td>
            <td><?= htmlspecialchars($u['name']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= htmlspecialchars($u['role']) ?></td>
            <td><?= (int)($u['active'] ?? 1) ? 'Yes' : 'No' ?></td>
            <td><?= htmlspecialchars($u['created_at']) ?></td>
            <td>
              <a class="btn btn-outline" href="<?= url('admin/edit?id=' . (int)$u['id']) ?>">Edit</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </form>
</div>

<script>
function toggleAll(source){
  const boxes = document.querySelectorAll('input[name="ids[]"]');
  for (const b of boxes) { b.checked = source.checked; }
}
</script>
