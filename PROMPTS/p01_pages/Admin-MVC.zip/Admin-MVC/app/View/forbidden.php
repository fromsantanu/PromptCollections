<h1>403 Forbidden</h1>
<p>You do not have permission to access this page.</p>
<p><a class="btn" href="<?= url('home') ?>">Back to Home</a></p>

