<?php

class HomePageController
{
    public function index(): void
    {
        $session = new SessionModel();
        $user = $session->currentUser();
        render_view('home_page_view.php', [
            'title' => 'Home',
            'user' => $user,
        ]);
    }
}

