<h1>Login</h1>
<div class="card">
  <form method="post" action="<?= url('login') ?>">
    <div>
      <label>Email</label>
      <input type="email" name="email" required />
    </div>
    <div>
      <label>Password</label>
      <input type="password" name="password" required />
    </div>
    <?php if (!empty($error)): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <div>
      <button class="btn" type="submit">Login</button>
      <a class="btn btn-outline" href="<?= url('register') ?>">Create New User</a>
    </div>
  </form>
</div>

