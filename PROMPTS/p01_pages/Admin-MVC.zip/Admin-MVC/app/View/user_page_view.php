<?php if (empty($user)) { $user = null; } ?>
<h1>User</h1>
<div class="card">
  <?php if ($user): ?>
    <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Role:</strong> <?= htmlspecialchars($user['role']) ?></p>
    <p><a class="btn" href="<?= url('logout') ?>">Logout</a></p>
  <?php else: ?>
    <p>You are not logged in.</p>
    <p><a class="btn" href="<?= url('login') ?>">Login</a></p>
  <?php endif; ?>
</div>

