<?php

class UserModel
{
    public function create(string $name, string $email, string $password, string $role = 'user'): int
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $pdo = db();
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
        $stmt->execute([$name, $email, $hash, $role]);
        return (int)$pdo->lastInsertId();
    }

    public function getByEmail(string $email): ?array
    {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function getById(int $id): ?array
    {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function all(): array
    {
        $pdo = db();
        $stmt = $pdo->query('SELECT id, name, email, role, active, created_at FROM users ORDER BY id DESC');
        return $stmt->fetchAll();
    }

    public function deleteByIds(array $ids): int
    {
        if (empty($ids)) return 0;
        $pdo = db();
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("DELETE FROM users WHERE id IN ($placeholders)");
        $stmt->execute(array_values($ids));
        return $stmt->rowCount();
    }

    public function setActiveByIds(array $ids, bool $active): int
    {
        if (empty($ids)) return 0;
        $pdo = db();
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("UPDATE users SET active = ? WHERE id IN ($placeholders)");
        $params = array_merge([(int)$active], array_values($ids));
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    public function promoteByIds(array $ids): int
    {
        if (empty($ids)) return 0;
        $pdo = db();
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE id IN ($placeholders)");
        $stmt->execute(array_values($ids));
        return $stmt->rowCount();
    }

    public function updateUser(int $id, array $data): bool
    {
        $fields = [];
        $params = [];
        if (isset($data['name'])) { $fields[] = 'name = ?'; $params[] = $data['name']; }
        if (isset($data['email'])) { $fields[] = 'email = ?'; $params[] = $data['email']; }
        if (isset($data['role'])) { $fields[] = 'role = ?'; $params[] = $data['role']; }
        if (isset($data['active'])) { $fields[] = 'active = ?'; $params[] = (int)$data['active']; }
        if (isset($data['password']) && $data['password'] !== '') {
            $fields[] = 'password_hash = ?';
            $params[] = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        if (empty($fields)) return false;
        $params[] = $id;
        $sql = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?';
        $pdo = db();
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }
}
