Admin‑MVC (PHP MVC Demo)

Overview
- Simple MVC structure with login, registration, user page, and admin management.
- MySQL database `test_db` with `users` and `sessions` tables.

Setup (XAMPP)
- Place the project under `htdocs` so the public root is `Admin-MVC/public`.
- Ensure Apache `mod_rewrite` is enabled; `.htaccess` routes to `public/index.php`.
- Copy `Admin-MVC/.env` and set DB credentials.
- Create schema: run `mysql -u root -p < Admin-MVC/sql/schema.sql` or import via phpMyAdmin.
- Alternatively, visit `Admin-MVC/database.php` to auto-create tables and seed admin.

Login
- Admin: email `admin@example.com`, password `admin123`.

Routes
- GET `home` → HomePageController@index
- GET/POST `login` → LoginPageController@index/login
- GET `logout` → LoginPageController@logout
- GET/POST `register` → NewUserPageController@index/create
- GET `user` → UserPageController@index (requires login)
- GET `admin` → AdminPageController@index (requires admin)
- POST `admin/action` → AdminPageController@action (bulk: delete/activate/deactivate/promote)
- GET `admin/edit?id={id}` → AdminPageController@edit
- POST `admin/edit` → AdminPageController@update

Config
- File: `Admin-MVC/app/config/config.php` reads `.env` and provides `db()` and `url()`.
- Public root: `Admin-MVC/public/` with `.htaccess` and `index.php` (router).

