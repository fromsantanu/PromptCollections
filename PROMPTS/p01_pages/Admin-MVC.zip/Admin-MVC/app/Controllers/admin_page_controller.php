<?php

class AdminPageController
{
    public function index(): void
    {
        $session = new SessionModel();
        if (!$session->isAuthenticated() || !$session->isAdmin()) {
            http_response_code(403);
            render_view('forbidden.php', ['title' => 'Forbidden']);
            return;
        }
        $userModel = new UserModel();
        $users = $userModel->all();
        render_view('admin_page_view.php', [
            'title' => 'Admin',
            'users' => $users,
            'user' => $session->currentUser(),
        ]);
    }

    public function action(): void
    {
        $session = new SessionModel();
        if (!$session->isAuthenticated() || !$session->isAdmin()) {
            http_response_code(403);
            render_view('forbidden.php', ['title' => 'Forbidden']);
            return;
        }
        $action = $_POST['action'] ?? '';
        $ids = array_map('intval', $_POST['ids'] ?? []);
        // Prevent deleting or demoting self by default for safety
        $me = $session->currentUser();
        if ($me && !empty($ids)) {
            $ids = array_values(array_filter($ids, fn($id) => $id !== (int)$me['id']));
        }
        $userModel = new UserModel();
        switch ($action) {
            case 'delete':
                $userModel->deleteByIds($ids);
                break;
            case 'activate':
                $userModel->setActiveByIds($ids, true);
                break;
            case 'deactivate':
                $userModel->setActiveByIds($ids, false);
                break;
            case 'promote':
                $userModel->promoteByIds($ids);
                break;
            default:
                // no-op
                break;
        }
        header('Location: ' . url('admin'));
        exit;
    }

    public function edit(): void
    {
        $session = new SessionModel();
        if (!$session->isAuthenticated() || !$session->isAdmin()) {
            http_response_code(403);
            render_view('forbidden.php', ['title' => 'Forbidden']);
            return;
        }
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) { header('Location: ' . url('admin')); exit; }
        $userModel = new UserModel();
        $u = $userModel->getById($id);
        if (!$u) { header('Location: ' . url('admin')); exit; }
        render_view('admin_user_edit_view.php', [
            'title' => 'Edit User',
            'u' => $u,
            'user' => $session->currentUser(),
        ]);
    }

    public function update(): void
    {
        $session = new SessionModel();
        if (!$session->isAuthenticated() || !$session->isAdmin()) {
            http_response_code(403);
            render_view('forbidden.php', ['title' => 'Forbidden']);
            return;
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) { header('Location: ' . url('admin')); exit; }
        $data = [
            'name' => trim($_POST['name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'role' => ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user',
            'active' => isset($_POST['active']) ? 1 : 0,
        ];
        if (!empty($_POST['password'])) {
            $data['password'] = (string)$_POST['password'];
        }
        // simple validation
        if ($data['name'] === '' || $data['email'] === '' || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            header('Location: ' . url('admin/edit?id=' . $id));
            exit;
        }
        $userModel = new UserModel();
        try {
            $userModel->updateUser($id, $data);
        } catch (Throwable $e) {
            // ignore and redirect back
        }
        header('Location: ' . url('admin'));
        exit;
    }
}
