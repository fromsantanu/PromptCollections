<?php

class UserPageController
{
    public function index(): void
    {
        $session = new SessionModel();
        if (!$session->isAuthenticated()) {
            header('Location: ' . url('login'));
            return;
        }
        $user = $session->currentUser();
        render_view('user_page_view.php', [
            'title' => 'User',
            'user' => $user,
        ]);
    }
}

