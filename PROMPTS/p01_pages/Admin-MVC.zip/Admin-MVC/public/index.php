<?php
// Front controller for Admin-MVC

declare(strict_types=1);

// Basic error reporting for development
ini_set('display_errors', '1');
error_reporting(E_ALL);

// Resolve paths
$root = dirname(__DIR__);
$appDir = $root . DIRECTORY_SEPARATOR . 'app';

// Start session early
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Autoloader for Controllers and Models (flat, simple)
spl_autoload_register(function ($class) use ($appDir) {
    $map = [
        'HomePageController' => $appDir . '/Controllers/home_page_controller.php',
        'LoginPageController' => $appDir . '/Controllers/login_page_controller.php',
        'NewUserPageController' => $appDir . '/Controllers/new_user_page_controller.php',
        'UserPageController' => $appDir . '/Controllers/user_page_controller.php',
        'AdminPageController' => $appDir . '/Controllers/admin_page_controller.php',
        'SessionModel' => $appDir . '/Models/session_model.php',
        'UserModel' => $appDir . '/Models/user_model.php',
    ];
    if (isset($map[$class]) && file_exists($map[$class])) {
        require_once $map[$class];
        return;
    }
});

// Load config (env + db connection)
require_once $appDir . '/config/config.php';

// Simple helper to render views with header/footer
function render_view(string $view, array $data = []): void {
    $viewPath = dirname(__DIR__) . '/app/View/' . $view;
    extract($data, EXTR_SKIP);
    $header = dirname(__DIR__) . '/app/View/partials/header.php';
    $footer = dirname(__DIR__) . '/app/View/partials/footer.php';
    if (file_exists($header)) include $header;
    if (file_exists($viewPath)) {
        include $viewPath;
    } else {
        http_response_code(404);
        echo '<h1>404 Not Found</h1>';
    }
    if (file_exists($footer)) include $footer;
}

// Routing
$path = isset($_GET['path']) ? trim((string)$_GET['path'], '/') : '';

// Controllers
$homeController = new HomePageController();
$loginController = new LoginPageController();
$newUserController = new NewUserPageController();
$userController = new UserPageController();
$adminController = new AdminPageController();

// Basic routes matching the provided pages
switch ($path) {
    case '':
    case 'home':
        $homeController->index();
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $loginController->login();
        } else {
            $loginController->index();
        }
        break;

    case 'logout':
        $loginController->logout();
        break;

    case 'register':
    case 'new-user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $newUserController->create();
        } else {
            $newUserController->index();
        }
        break;

    case 'user':
        $userController->index();
        break;

    case 'admin':
        $adminController->index();
        break;
    case 'admin/action':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $adminController->action();
        } else {
            header('Location: ' . url('admin'));
            exit;
        }
        break;
    case 'admin/edit':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $adminController->update();
        } else {
            $adminController->edit();
        }
        break;

    default:
        http_response_code(404);
        render_view('not_found.php', ['title' => 'Not Found']);
        break;
}
