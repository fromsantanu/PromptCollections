<?php

class SessionModel
{
    public function __construct()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }

    public function isAuthenticated(): bool
    {
        return isset($_SESSION['user_id']);
    }

    public function currentUser(): ?array
    {
        if (!$this->isAuthenticated()) return null;
        $userModel = new UserModel();
        return $userModel->getById((int)$_SESSION['user_id']);
    }

    public function isAdmin(): bool
    {
        $user = $this->currentUser();
        return $user && ($user['role'] ?? 'user') === 'admin';
    }

    public function login(string $email, string $password): bool
    {
        $userModel = new UserModel();
        $user = $userModel->getByEmail($email);
        if (!$user) return false;
        if (!password_verify($password, $user['password_hash'])) return false;
        if (isset($user['active']) && (int)$user['active'] === 0) return false;

        $_SESSION['user_id'] = (int)$user['id'];

        // Record session in DB table
        try {
            $pdo = db();
            $stmt = $pdo->prepare('INSERT INTO sessions (user_id, session_id) VALUES (?, ?)');
            $stmt->execute([$user['id'], session_id()]);
        } catch (Throwable $e) {
            // Ignore DB issues here; session remains active in PHP
        }

        return true;
    }

    public function logout(): void
    {
        // Remove from sessions table if present
        try {
            $pdo = db();
            $stmt = $pdo->prepare('DELETE FROM sessions WHERE session_id = ?');
            $stmt->execute([session_id()]);
        } catch (Throwable $e) {
            // ignore
        }

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }
}
