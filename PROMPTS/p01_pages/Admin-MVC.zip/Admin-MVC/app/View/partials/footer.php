  </main>
  <footer style="text-align:center;color:#666;padding:24px 0;border-top:1px solid #eee;">
    <small>Admin-MVC demo</small>
  </footer>
</body>
</html>

