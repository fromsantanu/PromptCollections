<?php

class LoginPageController
{
    public function index(array $data = []): void
    {
        render_view('login_page_view.php', [
            'title' => 'Login',
            'error' => $data['error'] ?? null,
        ]);
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $session = new SessionModel();
        if ($email === '' || $password === '') {
            $this->index(['error' => 'Email and password are required.']);
            return;
        }
        if ($session->login($email, $password)) {
            header('Location: ' . url('home'));
            exit;
        } else {
            $this->index(['error' => 'Invalid credentials.']);
        }
    }

    public function logout(): void
    {
        $session = new SessionModel();
        $session->logout();
        header('Location: ' . url('home'));
        exit;
    }
}
