<h1>404 Not Found</h1>
<p>The page you are looking for does not exist.</p>
<p><a class="btn" href="<?= url('home') ?>">Back to Home</a></p>

