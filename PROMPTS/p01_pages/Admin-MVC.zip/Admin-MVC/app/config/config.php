<?php
// Load environment variables from project .env (very simple parser)

$root = dirname(__DIR__, 2);
$envFile = $root . DIRECTORY_SEPARATOR . '.env';

if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) {
            $key = trim($parts[0]);
            $val = trim($parts[1]);
            $_ENV[$key] = $val;
        }
    }
}

// Defaults
$DB_HOST = $_ENV['127.0.0.1'] ?? '127.0.0.1';
$DB_PORT = (int)($_ENV['3306'] ?? '3306');
$DB_NAME = $_ENV['test_db'] ?? 'test_db';
$DB_USER = $_ENV['root'] ?? 'root';
$DB_PASS = $_ENV[''] ?? '';

// App URL base (for links). Adjust if served from different base path.
// Attempt to auto-detect from current script directory.
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
define('BASE_PATH', ($scriptDir === '' ? '/' : $scriptDir . '/'));

// Provide a singleton PDO connection
function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
    $port = (int)($_ENV['DB_PORT'] ?? '3306');
    $name = $_ENV['DB_NAME'] ?? 'test_db';
    $user = $_ENV['DB_USER'] ?? 'root';
    $pass = $_ENV['DB_PASS'] ?? '';

    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (Throwable $e) {
        http_response_code(500);
        echo '<h2>Database connection failed</h2>';
        echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
        exit;
    }
    return $pdo;
}

// Basic helper to build URLs
function url(string $path = ''): string {
    $path = ltrim($path, '/');
    return BASE_PATH . $path;
}

