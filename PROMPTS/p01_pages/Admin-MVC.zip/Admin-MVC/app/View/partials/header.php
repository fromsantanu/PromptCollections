<?php
// Shared header with simple nav
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= isset($title) ? htmlspecialchars($title) . ' | ' : '' ?>Admin-MVC</title>
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin:0; padding:0; color:#222; }
    header { background:#222; color:#fff; padding:12px 16px; }
    header a { color:#fff; text-decoration:none; margin-right:12px; }
    main { max-width:900px; margin:24px auto; padding:0 16px; }
    .card { border:1px solid #ddd; border-radius:6px; padding:16px; margin:12px 0; }
    .error { color:#b00020; margin-top:8px; }
    table { border-collapse: collapse; width:100%; }
    th, td { border:1px solid #ddd; padding:8px; text-align:left; }
    th { background:#f5f5f5; }
    .btn { display:inline-block; padding:8px 12px; border:1px solid #333; background:#333; color:#fff; border-radius:4px; text-decoration:none; }
    .btn-outline { background:#fff; color:#333; }
    form > div { margin-bottom:12px; }
    input[type=text], input[type=email], input[type=password] { width:100%; padding:8px; border:1px solid #ccc; border-radius:4px; }
  </style>
  <base href="<?= htmlspecialchars(BASE_PATH) ?>" />
</head>
<body>
  <header>
    <nav>
      <a href="<?= url('home') ?>">Home</a>
      <a href="<?= url('login') ?>">Login</a>
      <a href="<?= url('register') ?>">New User</a>
      <a href="<?= url('user') ?>">User</a>
      <a href="<?= url('admin') ?>">Admin</a>
      <span style="float:right">
        <?php if (!empty($user) && isset($user['name'])): ?>
          Hello, <?= htmlspecialchars($user['name']) ?>
          <a class="btn btn-outline" style="margin-left:8px" href="<?= url('logout') ?>">Logout</a>
        <?php endif; ?>
      </span>
    </nav>
  </header>
  <main>

