<?php

class NewUserPageController
{
    public function index(array $data = []): void
    {
        render_view('new_user_page_view.php', [
            'title' => 'Register',
            'error' => $data['error'] ?? null,
        ]);
    }

    public function create(): void
    {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['confirm'] ?? '');

        if ($name === '' || $email === '' || $password === '') {
            $this->index(['error' => 'All fields are required.']);
            return;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->index(['error' => 'Invalid email address.']);
            return;
        }
        if ($password !== $confirm) {
            $this->index(['error' => 'Passwords do not match.']);
            return;
        }
        try {
            $userModel = new UserModel();
            $userModel->create($name, $email, $password);
        } catch (Throwable $e) {
            $msg = 'Could not create user.';
            if (str_contains(strtolower($e->getMessage()), 'duplicate')) {
                $msg = 'Email already registered.';
            }
            $this->index(['error' => $msg]);
            return;
        }
        header('Location: ' . url('login'));
    }
}

