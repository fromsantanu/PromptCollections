<h1>New User</h1>
<div class="card">
  <form method="post" action="<?= url('register') ?>">
    <div>
      <label>Name</label>
      <input type="text" name="name" required />
    </div>
    <div>
      <label>Email</label>
      <input type="email" name="email" required />
    </div>
    <div>
      <label>Password</label>
      <input type="password" name="password" required />
    </div>
    <div>
      <label>Confirm Password</label>
      <input type="password" name="confirm" required />
    </div>
    <?php if (!empty($error)): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <div>
      <button class="btn" type="submit">Create Account</button>
      <a class="btn btn-outline" href="<?= url('login') ?>">Back to Login</a>
    </div>
  </form>
</div>

