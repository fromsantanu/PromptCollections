<?php $user = $user ?? null; ?>
<h1>Home</h1>
<div class="card">
  <p>Welcome to the PHP MVC demo.</p>
  <?php if ($user): ?>
    <p>You are logged in as <strong><?= htmlspecialchars($user['email']) ?></strong>.</p>
    <p>
      <a class="btn" href="<?= url('user') ?>">Go to User Page</a>
      <?php if (($user['role'] ?? 'user') === 'admin'): ?>
        <a class="btn" href="<?= url('admin') ?>" style="margin-left:8px">Go to Admin Page</a>
      <?php endif; ?>
    </p>
  <?php else: ?>
    <p>
      <a class="btn" href="<?= url('login') ?>">Login</a>
      <a class="btn btn-outline" href="<?= url('register') ?>" style="margin-left:8px">Create New User</a>
    </p>
  <?php endif; ?>
</div>

