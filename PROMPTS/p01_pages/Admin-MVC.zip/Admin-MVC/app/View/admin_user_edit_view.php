<h1>Edit User</h1>
<div class="card">
  <form method="post" action="<?= url('admin/edit') ?>">
    <input type="hidden" name="id" value="<?= (int)$u['id'] ?>" />
    <div>
      <label>Name</label>
      <input type="text" name="name" value="<?= htmlspecialchars($u['name']) ?>" required />
    </div>
    <div>
      <label>Email</label>
      <input type="email" name="email" value="<?= htmlspecialchars($u['email']) ?>" required />
    </div>
    <div>
      <label>Role</label>
      <select name="role">
        <option value="user" <?= ($u['role']==='user')?'selected':'' ?>>User</option>
        <option value="admin" <?= ($u['role']==='admin')?'selected':'' ?>>Admin</option>
      </select>
    </div>
    <div>
      <label>Active</label>
      <input type="checkbox" name="active" <?= ((int)($u['active'] ?? 1)) ? 'checked' : '' ?> />
    </div>
    <div>
      <label>New Password (optional)</label>
      <input type="password" name="password" />
    </div>
    <div>
      <button class="btn" type="submit">Save</button>
      <a class="btn btn-outline" href="<?= url('admin') ?>">Cancel</a>
    </div>
  </form>
</div>

